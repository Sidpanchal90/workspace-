package com.employee.srvices.Model;

import lombok.Data;

@Data
public class User {

	private String userId;
	private String name;
	private String email;

}
