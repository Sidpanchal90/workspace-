/*
 * package com.employee.srvices;
 * 
 * import org.junit.jupiter.api.Test; import
 * org.springframework.boot.test.context.SpringBootTest;
 * 
 * @SpringBootTest class EmployeeSecurityApplicationTests {
 * 
 * @Test void contextLoads() { }
 * 
 * }
 */